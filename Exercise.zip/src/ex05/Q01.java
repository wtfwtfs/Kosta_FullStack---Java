package ex05;

public class Q01 {

	public static void main(String[] args) {
		int[] arr[];
		int[] arr1 = {1,2,3,};
		int[] arr2 = new int[5];
		//int[] arr3 = new int[5]{1,2,3,4,5};
		int[] arr3 = new int[] {1,2,3,4,5};
		//int arr4[5];
		
		int[] arr5[] = new int[3][];

	}

}
