//1+(1+2)+(1+2+3)+(1+2+3+4)+...+(1+2+3+...+10)의 결과를 계산하시오.
package ex04;

public class Q03 {

	public static void main(String[] args) {
		int sum=0;
		for(int i=1;i<11;i++) {
			for(int j=1;j<=i;j++) {
				sum += j;
			}
		}
		System.out.println(sum);

	}

}
//1			i=1 , j=1
//1,2		i=2 , j=1-2
//1,2,3		i=3 , j=1-3
//...
//1,2..10	i=10 , j=1-10