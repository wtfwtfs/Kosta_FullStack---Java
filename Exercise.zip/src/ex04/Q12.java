package ex04;

public class Q12 {

	public static void main(String[] args) {
		for (int sdan = 2; sdan < 9; sdan += 3) {
			for (int i = 1; i <= 3; i++) {
				for (int dan = sdan; dan <= (sdan + 2 < 10 ? sdan + 2 : sdan + 1); dan++) {
					System.out.print(String.format("%d*%d=%d\t", dan, i, dan * i));
				}
				System.out.println();
			}
			System.out.println();
		}
	}
}
