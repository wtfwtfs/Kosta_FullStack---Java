package ex07;

public class SutdaDeck {
	
	final int CARD_NUM = 20;
	SutdaCard[] cards = new SutdaCard[CARD_NUM];

	SutdaDeck() {
		for(int i=0; i<10; i++) {
			if(i+1==1 || i+1==3 || i+1==8) {
				cards[i] = new SutdaCard(i+1,true);
			}else {
				cards[i] = new SutdaCard(i+1,false);
			}
			cards[i+10] = new SutdaCard(i+1,false);
		}
	}
	
	public void shuffle() {
		for(int i=0; i<100; i++) {
			int idx1 = (int)(Math.random()*20);
			int idx2 = (int)(Math.random()*20);
			SutdaCard temp = cards[idx1];
			cards[idx1] = cards[idx2];
			cards[idx2] = temp;
		}
	}
	
	public SutdaCard pick(int idx) {
		return cards[idx];
	}
	
	public SutdaCard pick() {
		int idx = (int)(Math.random()*20);
		return cards[idx];
	}
}