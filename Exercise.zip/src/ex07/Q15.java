package ex07;

public class Q15 {
	public static void main(String[] args) {
		 class Unit {}
		 class AirUnit extends Unit {}
		 class GroundUnit extends Unit {}
		 class Tank extends GroundUnit {}
		 class AirCraft extends AirUnit {}
		 Unit u = new GroundUnit();
		 Tank t = new Tank();
		 AirCraft ac = new AirCraft();
		 
		 
		 u = (Unit)ac;
		 u = ac;  //업케스팅  u=(Unit)ac;로 괄호와 Unit은 생략해도 된다
		 GroundUnit gu = (GroundUnit)u; //다운캐스팅
		 AirUnit au = ac; //업케스팅 
		 t = (Tank)u; // 다운캐스팅, 잘못 사용한 예
		 GroundUnit gu1 = t; //업케스팅 
	}
}
