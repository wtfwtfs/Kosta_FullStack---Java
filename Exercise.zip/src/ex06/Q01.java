//다음과 같은 멤버변수를 갖는 SutdaCard클래스를 정의하시오.
package ex06;


public class Q01 {//SutdaCard 클래스
	
	int num;
	boolean isKwang;

}
// int num 카드의 숫자.(1~10 사이의 정수)
// boolean isKwang 광이면 true 아니면 false