package ex06;
//문제6-1에서 정의한 StudaCard클래스에 두 개의 생성자와 info()를 추가해서 실행
//결과와 같은 결과를 얻도록 하시오.
class SutdaCard {
	int num =1;
	boolean isKwang;
	
	SutdaCard(){
		this(1,true);
	}//기본생성자가 있어야 아래 card2가 나올수 있다. num은 1이고 isKwang은 true 일때 k가 출력되도록
	
	SutdaCard(int num, boolean isKwang){
		this.num=num;
		this.isKwang=isKwang;
	}
	
	String info() {
		return num+(isKwang?"K":"");
	}

}

public class Q02 {

	public static void main(String[] args) {
		 SutdaCard card1 = new SutdaCard(3, false);
		 SutdaCard card2 = new SutdaCard();
		 System.out.println(card1.info());
		 System.out.println(card2.info());

	}

}

//실행결과
//3
//1k