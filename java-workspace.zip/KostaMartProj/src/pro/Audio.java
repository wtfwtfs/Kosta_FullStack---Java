package pro;

public class Audio extends Product {
	public Audio() {
		price = 200;
		bonusPoint =20;
	}
	
	@Override
	public String toString() {
		return "오디오";
	}
}
