package emp;

public class Sales extends Employee {

	public Sales(String name, int pay) {
		super(name, pay);
	}

	public Sales(String name, int pay, int incentive) {

		super(name, pay);
		this.pay = pay + incentive;
	}
	
//	int incentive;
//	public Sales(String name, int pay, int incentive) {
//		super(name, pay);
//		this.incentive=incentive;
//	}
//	public int getIncentive() {
//		return incentive;
//	}
//	
//	public void setIncentive() {
//		return incentive = incentive;
//	}
//	
//	@Override
//	public String info() {
//		return String.format("사번:%s, 이름:%s, 급여:%s", num,name,getIncentive()+setIncentive());
//	}

	public static void main(String[] args) {
		Sales emp1 = new Sales("홍길동", 1000000, 500000);
		Sales emp2 = new Sales("김길동", 2000000);
		Sales emp3 = new Sales("하길동", 3000000, 100000);
		System.out.println(emp1.info());
		System.out.println(emp2.info());
		System.out.println(emp3.info());
	}
}
//사번:20151, 이름:홍길동, 급여:1500000
//사번:20152, 이름:김길동, 급여:2500000
//사번:20153, 이름:하길동, 급여:3100000