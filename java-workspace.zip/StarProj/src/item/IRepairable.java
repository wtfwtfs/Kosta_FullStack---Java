package item;

public interface IRepairable {
	
	void fix();
}
