
public class RandomTest {

	public static void main(String[] args) {
		int rand = (int)(Math.random()*45)+1;
		System.out.println(rand);
		
		int rand2 = (int)(Math.random()*100);
		System.out.println(rand2);
	}

}
