//*을 5by5 print를 사용
public class ForTest6 {

	public static void main(String[] args) {

		int i,j=1;
		for (i = 1; i < 6; i++) {
			for (j = 1; j < 6; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println();

/////////////////////////////////////////////////////////
		for(i =1; i<6; i++) {
			for(j=1;j<=i;j++) {
				System.out.print("*");
			}
		System.out.println();
		}
		System.out.println();
		
//////////////////////////////////////////////////////////
		
		
	}

}
