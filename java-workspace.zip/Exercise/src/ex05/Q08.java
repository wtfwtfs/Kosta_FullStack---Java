package ex05;

public class Q08 {

    public static void main(String[] args) {
        int[] answer = { 1, 4, 4, 3, 1, 4, 4, 2, 1, 3, 2 };
        int[] counter = new int[4];
        
        // 숫자 카운트
        for (int i = 0; i < answer.length; i++) {
            counter[answer[i] - 1]++;  // answer[i]가 1이면 counter[0] 증가
        }
        
        // 결과 출력
        for (int i = 0; i < counter.length; i++) {
            System.out.print(i + 1); // 숫자만 출력 (1부터 4까지)
            for (int j = 0; j < counter[i]; j++) {
                System.out.print("*"); // 별 출력
            }
            System.out.println();
        }
    }
}
