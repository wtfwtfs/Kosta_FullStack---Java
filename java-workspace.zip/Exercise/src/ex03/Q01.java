package ex03;
//다음 연산의 결과를 적으시오
public class Q01 {

	public static void main(String[] args) {
		int x = 2;
		int y = 5;
		char c ='A'; //'A'의 문자코드는 65
		
		System.out.println(1+x << 33); //비트 연산 int 32비트를 넘어서 자동 보정으로 계산 하지만 이렇게 사용은 지양
		System.out.println(y >= 5 || x < 0 && x >2); //and가 or 보다 순위가 높다, and는 앞 항이 거짓이면 뒷 연산은 하지 않고참이면 연산은 한다, or는 앞 항이 참일때 뒤 항을 연산하지 않음
		System.out.println(y += 10 - x++);// ++ 순위가 가장 높지만 x뒤에 위치, 먼저 계산후 계산 후 ++ 그리고 y+8이 결과가 된다.
		System.out.println(x+=2); 
		System.out.println(!('A' <= c && c<='z'));
		System.out.println('C'-c);
		System.out.println('5'-'0');
		System.out.println(c+1); // char가 변경 되어 계산
		System.out.println(++c); // ++은 타입 유지
		System.out.println(c++); // ++은 타입 유지 
		System.out.println(c);
		
		
	}

}
