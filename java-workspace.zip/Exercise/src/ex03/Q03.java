package ex03;
//아래는 변수 num의 값에 따라 '양수','음수', '0'을 출력하는 코드이다. 삼항 연산자를 이용해 (1)에 알맞은 코드를 넣으시오 [Hint]삼항 연산자를 두번 사용하라
public class Q03 {

	public static void main(String[] args) {
		int num = 0;
		//System.out.println(/*(1)*/);
		System.out.println(num>0? "양수":num<0?"음수":"0");
		
		
		//삼항 연산자, if 문을 연산자로 나타낼수 있음
		//ex) int x= -10;
		//	  int absX = x >= 0? x:-x;
		//아래와 같이 >>>>
		// -> if(x>=10){
		//		absX = x;
		//    else {
		//		abxX = -x;
		//	  }
		
		//삼항 연산자 두번 사용
		//ex) int score = 50;
		//	  char grade = score >= 90? 'A': (score >= 80? 'B': 'C');
		
	}

}
