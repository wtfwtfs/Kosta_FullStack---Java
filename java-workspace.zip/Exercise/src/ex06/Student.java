// 다음과 같은 멤버변수를 갖는 Student클래스를 정의하시오.

package ex06;

public class Student {
	String name;
	int ban;
	int no;
	int kor;
	int eng;
	int math;
	
	Student(){}//아래 생성자로 인해 기본생성자가 없어지므로 기본생성자를 추가해야 Q04가 에러가 나지 않는다
	
	Student(String name, int ban, int no, int kor, int math, int eng){
		 this.name=name;
		 this.ban=ban;
		 this.no=no;
		 this.kor=kor;
		 this.eng=eng;
		 this.math=math;
	 }
	
	int getTotal() {
		return kor+eng+math;
	}
	
	float getAverage() {
		float avg = getTotal()/3f;
		return Math.round(avg*10)/10f;
	}
	
	String info() {
		 return String.format("%s,%d,%d,%d,%d,%d,%d,%f ", name, ban, no, kor, eng, math,getTotal(),getAverage() );
	 }
}


