//다음의 코드는 컴파일하면 에러가 발생한다. 그 이유를 설명하고 에러를 수정하기 
//위해서는 코드를 어떻게 바꾸어야 하는가?

package ex07;

class Product {
	int price; // 제품의 가격
	int bonusPoint; // 제품구매 시 제공하는 보너스점수
	
	Product(int price) {
		this.price = price;
		bonusPoint = (int) (price / 10.0);
	}
}

class Tv extends Product {
//	Tv() {
//		
//	}
	
	Tv() {
		super(500);
	}
	
	
	public String toString() {
		return "Tv";
	}
}

class Q03 {
	public static void main(String[] args) {
		Tv t = new Tv();
	}
}
// TV(){}에서 오류,  부모클래스에 기본생성자를 기입하거나 자식클래스에서 TV부분을 부모의 생성자의 형태로 쓴다. 생성자(초기화 하는 이벤트);