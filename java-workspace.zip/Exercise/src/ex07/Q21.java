package ex07;

interface Movable {
	void move(int x, int y);
}

public class Q21 {
	static void attack(Movable f) {
		/*내용 생략*/
	}
	
	public static void main(String[] args) {
		attack(null);
		Movable m = (new Movable(){
			@Override
			public void move(int x, int y) {
			}
		});
		//(위)이거 자체가 업캐스팅
		
		attack(m);
	}
}
