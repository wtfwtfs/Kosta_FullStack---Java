// public class Exercise4_5 { 
//public static void main(String[] args) { 
//for(int i=0; i<=10; i++) {
// for(int j=0; j<=i; j++)
// System.out.print("*");
// System.out.println();
// }
// } // end of main 
//} // end of class 
//while문 변경

package ex04;

public class Q05 {

	public static void main(String[] args) {
		int i=0,j;
		while(i<=10) {
			j=0;
			while(j<= i) {
				System.out.print("*");
				j++;
			}
			System.out.println();
			i++;
		}
	}

}
