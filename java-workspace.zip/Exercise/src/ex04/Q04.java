//1+(-2)+3+(-4)+...  과 같은 식으로 계속 더해나갔을 때, 몇까지 더해야 총합이 100이상이 되는지 구하시오.
package ex04;

public class Q04 {

	public static void main(String[] args) {
		int sum = 0, i;
		for (i = 1;; i++) {
			sum += i % 2 == 0 ? -i : i;
			if (sum >= 100)
				break;
		}

		System.out.println(String.format("i:%d, sum:%d", i, sum));

		System.out.println();

////////////////////////////////////////////////////////////////////

		int sum1 = 0, j;
		for (j = 1; sum1 < 100; j++) {
			if (j % 2 != 0) {
				sum1 += j;
			} else {
				sum1 -= j;
			}
		}
		System.out.println(String.format("j:%d, sum1:%d", j-1, sum1));
		
	}

}
