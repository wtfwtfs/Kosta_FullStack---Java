//Math.random()을 이용해서 1부터 6사이의 임의의 정수를 변수 value에 저장하는 코드를 완성하라. (1)에 알맞은 코드를 넣으시오.
package ex04;

public class Q07 {

	public static void main(String[] args) {
			 int value = (int)(Math.random()*6)+1;
			 System.out.println("value:"+value);

	}

}


// 0<Math.random()<1
// 1<Math.random()*6+1<7