public class Person{
    public String name;
    public String address;

    public String toString(){
        return "{name="+name+",address="+address+"}";
        //return "안녕";
    }
}