public class ToStringTest{
    public static void main(String[] args) throws Exception{
        Person person = new Person();
        person.name="이순신";
        person.address="여수시";

        System.out.println(person.toString());
    }
}