Java Network class

Stream / Collection / Network
