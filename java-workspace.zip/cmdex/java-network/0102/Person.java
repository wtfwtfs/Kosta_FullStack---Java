import java.io.Serializable;

public class Person implements Serializable{

    public String name;
    public String tel;
    public String address;
    public String birth;
}