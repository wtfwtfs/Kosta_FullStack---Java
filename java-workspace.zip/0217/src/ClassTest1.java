class Person{
	int age;
	String name;
}


public class ClassTest1 {

	public static void main(String[] args) {
		int n = 10;
		
		Person p = new Person();
		p.age =20;
		p.name = "홍길동";
		
		Person p2 = new Person();
		p2.age=30;
		p2.name="박길동";
		
		
	}

}
