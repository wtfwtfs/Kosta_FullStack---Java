
public class ArrayTest1 {

	public static void main(String[] args) {
		int [] arr1 = new int[5];
		arr1[0] =10;
		arr1[1] =20;
		arr1[2] =30;
		arr1[3] =40;
		arr1[4] =50;
		
		int[] arr2 = new int[] {10,20,30,40,50};
		
		int[] arr3 = {10,20,30,40,50};
		// 위 세가지 모두 같다
		
		System.out.println(arr1[0]);
		System.out.println(arr1.length);
		
		double [] darr1;		
		
		int n;
		double d;
		
		

	}

}
