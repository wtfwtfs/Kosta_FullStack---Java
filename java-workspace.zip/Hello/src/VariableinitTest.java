
public class VariableinitTest {

	public static void main(String[] args) {
		int n,m,k;
		n=m=k=0;
		System.out.println(n);
		
		

	}

}
