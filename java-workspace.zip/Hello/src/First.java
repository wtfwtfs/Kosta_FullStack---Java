//import java.util.Scanner;
public class First {

	public static void main(String[] args) {
		
//		Scanner scan = new Scanner(System.in);
//		
//		System.out.print("원을 넓이를 구하는 프로그램입니다.");
//		System.out.println("구하고 싶은 원의 반지름을 입력하세요");
//		int r = scan.nextInt();
//		System.out.println("원주율은 3.14로 계산됩니다.");
//		System.out.println("원의 넓이는 " + r*r*3.14 + "입니다");
//		
//		scan.close();
//		System.out.println("프로그램 종료");
		
		char ch = '홍';
		String str = "홍";
		System.out.println(ch + " " + str);
		System.out.println(7+7+"7");
		System.out.println("7"+7+7);
		
		float height = 178.3f;
		int nh = (int)height;
		System.out.println(height);
		System.out.println(nh);
		double d = height;
		float h = (float)height;
		System.out.println(h);
		int m = 10;
		byte b =(byte)m;
		System.out.println(b);
		char a = 'a';
		int na = (int)a;
		System.out.println(a);
		System.out.println(na);
		System.out.println((char)na);
		
	}

}