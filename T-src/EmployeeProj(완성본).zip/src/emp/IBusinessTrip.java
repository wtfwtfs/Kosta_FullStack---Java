package emp;

public interface IBusinessTrip {
	void goBusinessTrip(int day);
}
