package emp;
public class Employee {
	final static int YEAR = 2015;
	static int empNum = 1;
	String num;
	String name;
	int pay;
	
	public String getNum() {
		return num;
	}

	public Employee(String name, int pay) {
		num = ""+YEAR+empNum++;
		this.name=name;
		this.pay=pay;
	}
	
	public Employee(String num, String name, int pay) {
		this.num=num;
		this.name=name;
		this.pay=pay;
	}
	
	public String info() {
		return String.format("���:%s,�̸�:%s,�޿�:%d",num,name,pay);
	}
	
	public void setPay(int pay) {
		this.pay = pay;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPay() {
		return pay;
	}
	public void setBonus(int money) {
		pay += money;
	}
}