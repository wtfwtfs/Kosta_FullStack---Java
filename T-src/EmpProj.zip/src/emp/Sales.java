package emp;

public class Sales extends Employee {
	int incentive;
	
	public Sales(String name,int pay) {
		super(name,pay);
	}
	public Sales(String name,int pay, int incentive) {
		super(name,pay);
		this.incentive=incentive;
	}
	
	public int getIncentive() {
		return incentive;
	}
	public void setIncentive(int incentive) {
		this.incentive = incentive;
	}
	@Override
	public String info() {
		return String.format("���:%s,�̸�:%s,�޿�:%d",num,name,getPay()+getIncentive());
	}
	
	public static void main(String[] args) {
		Sales emp1 = new Sales("ȫ�浿",1000000,500000);
		Sales emp2 = new Sales("��浿",2000000);
		Sales emp3 = new Sales("�ϱ浿",3000000,100000);
		System.out.println(emp1.info());
		System.out.println(emp2.info());
		System.out.println(emp3.info());
	}

}
//���:20151,�̸�:ȫ�浿,�޿�:1500000
//���:20152,�̸�:��浿,�޿�:2000000
//���:20153,�̸�:�ϱ浿,�޿�:3100000