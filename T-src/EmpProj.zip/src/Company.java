import emp.Employee;

public class Company {
	Employee[] emps = new Employee[100];
	int cnt = 0;
	
	void enter(Employee emp) {
		emps[cnt++] = emp;
	}
	
	void allEmpInfo() {
		for(int i=0; i<cnt; i++) {
			System.out.println(emps[i].info());
		}
	}
	
	Employee findEmp(String num) {
		Employee emp = null;
		for(int i=0; i<cnt; i++) {
			if(emps[i].getNum().equals(num)) {
				emp = emps[i];
				break;
			}
		}
		return emp;
	}
	
	void setPay(String num, int pay) {
		Employee emp = findEmp(num);
		if(emp==null) {
			System.out.println("����� Ʋ���ϴ�.");
			return;
		}
		emp.setPay(pay);
	}
	
	void bonus(String num, int money) {
		Employee emp = findEmp(num);
		if(emp==null) {
			System.out.println("����� Ʋ���ϴ�.");
			return;
		}
		emp.setBonus(money);
	}
	
	public static void main(String[] args) {
		Company com = new Company();
		
//		com.enter(new Employee("1001","ȫ�浿",100000));
//		com.enter(new Employee("1002","��浿",200000));
//		com.enter(new Employee("1003","�ڱ浿",300000));
//		com.setPay("1001",1000000);
//		com.bonus("1002",500000);

		com.enter(new Employee("ȫ�浿",100000));
		com.enter(new Employee("��浿",200000));
		com.enter(new Employee("�ڱ浿",300000));
		
		
		com.allEmpInfo();
	}
}

//��°��
//���:1001,�̸�:ȫ�浿,�޿�:1000000
//���:1002,�̸�:��浿,�޿�:700000
//���:1003,�̸�:�ڱ浿,�޿�:300000