interface IClick {
	void click();
}
interface IDoubleClick {
	void doubleClick();
}

class Button {
	IClick iclick;
	IDoubleClick idoubleClick;
	void addClickListener(IClick iclick) {
		this.iclick=iclick;
	}
	void addDoubleClickListner(IDoubleClick idoubleClick) {
		this.idoubleClick = idoubleClick;
	}
	void onClick() {
		System.out.println("�� ���� ����");
		if(iclick!=null) {
			iclick.click();
		}
	}
	void onDoubleClick() {
		if(idoubleClick!=null) {
			idoubleClick.doubleClick();
		}
	}
}

public class InterfaceTest2 {
	public static void main(String[] args) {
		Button login = new Button();
		
		IClick c = new IClick() {
			
			@Override
			public void click() {
				System.out.println("�α��� ó��");
				
			}
		};
		
		login.addClickListener(c);
		login.onClick();
		
		Button join = new Button();
		join.addClickListener(new IClick() {
			@Override
			public void click() {
				System.out.println("ȸ������ ó��");
			}
		});
		join.onClick();
		
		Button menu = new Button();
		menu.addDoubleClickListner(new IDoubleClick() {
			@Override
			public void doubleClick() {
				System.out.println("���ؽ�Ʈ �޴�");
			}
		});
		
		menu.onDoubleClick();
		
		Button login2 = new Button() {
			@Override
			void onClick() {
				super.onClick();
				System.out.println("�α��� ó��");
			}
		};
		
		login2.onClick();
		
		Button join2 = new Button() {
			@Override
			void onClick() {
				super.onClick();
				System.out.println("ȸ������ ó��");
			}
		};
		join2.onClick();
	}
}