class Person extends Object { //���
	int age;
	String name;
	
	@Override
	public String toString() {  //overriding
		return String.format("�̸�:%s,����:%d", name,age);
	}
}
public class PolinoTest1 {

	public static void main(String[] args) {
//		Person p = new Person();
//		p.age=20;
//		p.name="hong";
//		System.out.println(p.toString());
		
		Object p2 = new Person(); //upcasting
//		p2.age=30;
//		p2.name="pong";
		System.out.println(p2.toString()); //

	}

}
