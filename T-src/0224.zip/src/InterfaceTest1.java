class Unit {
	int x, y;
	public void stop() {}
}
interface Movable {
	void move(int x, int y);
}
interface Attackable {
	void attack(Unit u);
}

interface Fightable extends Movable, Attackable {}

class Fighter extends Unit implements Fightable {

	@Override
	public void move(int x, int y) {}

	@Override
	public void attack(Unit u) {}
}

public class InterfaceTest1 {
	public static void main(String[] args) {
		Fighter f1 = new Fighter(); 
		f1.stop();
		f1.move(0, 0);
		f1.attack(null);
		
		Unit f2 = new Fighter();
		Fightable f3 = new Fighter();
		Movable f4 = new Fighter();
		Attackable f5 = new Fighter();
		Object f6 = new Fighter();
		 
		f2.stop();//O 
//		f2.move(0, 0); //X
//		f2.attack(null); //X
		
//		f3.stop(); //X
		f3.move(0, 0); //O
		f3.attack(null); //O
		
//		f4.stop(); //X
		f4.move(0, 0); //O
//		f4.attack(null); //X
		
//		f5.stop(); //X
//		f5.move(0, 0); //X
		f5.attack(null); //O
		
	}

}
